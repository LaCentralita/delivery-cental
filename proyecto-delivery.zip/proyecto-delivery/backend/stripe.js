import { Router } from 'express'
import Stripe from 'stripe'

const router = Router()
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '')

router.post('/', async (req, res) => {
  try {
    const { items } = req.body
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Items requeridos' })

    const line_items = items.map(i => ({
      price_data: {
        currency: 'mxn',
        product_data: { name: i.nombre },
        unit_amount: Math.round(Number(i.precio) * 100)
      },
      quantity: Number(i.qty || 1)
    }))

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items,
      success_url: process.env.SUCCESS_URL || 'http://localhost:5173/?status=success',
      cancel_url: process.env.CANCEL_URL || 'http://localhost:5173/?status=cancel'
    })

    res.json({ url: session.url })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Error creando sesión de Stripe' })
  }
})

export default router
