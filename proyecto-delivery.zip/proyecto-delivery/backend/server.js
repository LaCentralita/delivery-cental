import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import bodyParser from 'body-parser'
import stripeRouter from './stripe.js'
import mpRouter from './mercadopago.js'

const app = express()
const PORT = process.env.PORT || 3001

app.use(cors())
app.use(bodyParser.json())

app.get('/api/health', (req, res) => res.json({ ok: true }))

app.use('/api/pay/stripe', stripeRouter)
app.use('/api/pay/mp', mpRouter)

app.listen(PORT, () => console.log(`API escuchando en :${PORT}`))
