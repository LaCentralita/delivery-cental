import { Router } from 'express'
import mercadopago from 'mercadopago'

const router = Router()

const MP_TOKEN = process.env.MP_ACCESS_TOKEN || ''
mercadopago.configure({ access_token: MP_TOKEN })

router.post('/', async (req, res) => {
  try {
    const { items } = req.body
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Items requeridos' })

    const preference = {
      items: items.map(i => ({
        title: i.nombre,
        unit_price: Number(i.precio),
        quantity: Number(i.qty || 1),
        currency_id: 'MXN'
      })),
      back_urls: {
        success: process.env.SUCCESS_URL || 'http://localhost:5173/?status=success',
        failure: process.env.CANCEL_URL || 'http://localhost:5173/?status=failure',
        pending: process.env.PENDING_URL || 'http://localhost:5173/?status=pending'
      },
      auto_return: 'approved'
    }

    const response = await mercadopago.preferences.create(preference)
    res.json({ init_point: response.body.init_point })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Error creando preferencia MP' })
  }
})

export default router
