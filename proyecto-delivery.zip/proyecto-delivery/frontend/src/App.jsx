import React, { useMemo, useState } from 'react'
import './app.css'

const INVENTARIO = [
  { id: 1, nombre: 'Jalapeño', precio: 15 },
  { id: 2, nombre: 'Limón', precio: 8 },
  { id: 3, nombre: 'Tomate', precio: 10 },
  { id: 4, nombre: 'Cebolla', precio: 6 },
  { id: 5, nombre: 'Aguacate', precio: 20 },
  { id: 6, nombre: 'Zanahoria', precio: 8 },
]

export default function App() {
  const [carrito, setCarrito] = useState([])
  const apiURL = __API_URL__

  const total = useMemo(() => carrito.reduce((acc, i) => acc + i.precio * i.qty, 0), [carrito])

  function addItem(item) {
    setCarrito(prev => {
      const found = prev.find(p => p.id === item.id)
      if (found) return prev.map(p => p.id === item.id ? { ...p, qty: p.qty + 1 } : p)
      return [...prev, { ...item, qty: 1 }]
    })
  }

  function removeItem(id) {
    setCarrito(prev => prev.filter(p => p.id !== id))
  }

  async function checkoutStripe() {
    if (carrito.length === 0) return alert('Tu carrito está vacío')
    const res = await fetch(`${apiURL}/pay/stripe`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: carrito })
    })
    const data = await res.json()
    if (data?.url) window.location.href = data.url
    else alert('Error iniciando Stripe')
  }

  async function checkoutMP() {
    if (carrito.length === 0) return alert('Tu carrito está vacío')
    const res = await fetch(`${apiURL}/pay/mp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: carrito })
    })
    const data = await res.json()
    if (data?.init_point) window.location.href = data.init_point
    else alert('Error iniciando MercadoPago')
  }

  return (
    <>
      <header>
        <h1>Frutas & Verduras</h1>
        <div className="badge">Entrega en 90 min</div>
      </header>

      <div className="container">
        <h2>Cátalogo</h2>
        <div className="grid">
          {INVENTARIO.map(p => (
            <div className="card" key={p.id}>
              <h3>{p.nombre}</h3>
              <p>${p.precio} / kg</p>
              <button onClick={() => addItem(p)}>Agregar</button>
            </div>
          ))}
        </div>

        <div className="cart">
          <h2>🛒 Carrito</h2>
          <ul>
            {carrito.map(item => (
              <li key={item.id}>
                <span>{item.nombre} × {item.qty}</span>
                <span>${(item.precio * item.qty).toFixed(2)}</span>
                <button onClick={() => removeItem(item.id)}>Quitar</button>
              </li>
            ))}
          </ul>
          <div className="total">
            <span>Total</span>
            <span>${total.toFixed(2)}</span>
          </div>
          <div className="actions">
            <button className="btn-stripe" onClick={checkoutStripe}>Pagar con Stripe</button>
            <button className="btn-mp" onClick={checkoutMP}>Pagar con MercadoPago</button>
          </div>
        </div>
      </div>

      <footer>© 2025 Delivery FyV</footer>
    </>
  )
}
